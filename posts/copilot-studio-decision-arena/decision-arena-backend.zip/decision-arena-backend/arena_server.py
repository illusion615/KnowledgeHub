import concurrent.futures
import http.client
import io
import json
import queue
import re
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from cs_benchmark_presets import build_customer_service_presets

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

FOUNDRY_HOST = "wellszhang-quickdecisio-resource.cognitiveservices.azure.com"
FOUNDRY_PATH = "/providers/microsoft/v1/systemone"
DL_HOST = "9ffec6fe9e60eaf8921dbe20e366a1.9b.environment.api.powerplatform.com"
DL_BOT_SCHEMA = "cre47_csmonolithbencha"

AGENT_SCHEMAS = {
    "A": "cre47_csmonolithbencha",
    "B": "cre47_cshybridtoolbenchb",
    "C": "cre47_cshookbenchc",
    "D_SPEC": "cre47_csfreshclaimspecialistd",
}
AGENT_LABELS = {
    "A": "CS Monolith Bench A (cre47_csmonolithbencha · 6模块巨型客服单体)",
    "B": "CS Hybrid Tool Bench B (cre47_cshybridtoolbenchb · 内部调Decision-1工具)",
    "C": "CS Hook Bench C (cre47_cshookbenchc · 前置Hook工作流)",
    "D": "Decision-1 顶层网关 + 前置状态机 + CS Fresh Claim Specialist D (cre47_csfreshclaimspecialistd)",
}

FOUNDRY_PRICE_PER_1M_USD = 0.042
CREDIT_USD_RATE = 0.01

_TOKEN_CACHE = {}
_LOCK = threading.Lock()
_CONV_POOL = {"A": [], "B": [], "C": [], "D_SPEC": []}
_POOL_LOCK = threading.Lock()
_FOUNDRY_KEEPALIVE_CONN = None
_FOUNDRY_LOCK = threading.Lock()

# Multi-turn session store: session_id -> session dict
_SESSIONS = {}
_SESSIONS_LOCK = threading.Lock()
_ACTIVE_STREAMS = 0
_ACTIVE_STREAMS_LOCK = threading.Lock()


def get_az_token(resource, force_refresh=False):
    now = time.time()
    with _LOCK:
        if not force_refresh:
            cached = _TOKEN_CACHE.get(resource)
            if cached and cached[1] - now > 300:
                return cached[0]
    res = subprocess.run(
        ["az", "account", "get-access-token", "--resource", resource, "-o", "json"],
        capture_output=True, text=True, timeout=30, check=False
    )
    if res.returncode != 0:
        return None
    data = json.loads(res.stdout)
    tok = data.get("accessToken")
    exp = float(data.get("expires_on") or (now + 900))
    with _LOCK:
        _TOKEN_CACHE[resource] = (tok, exp)
    return tok


def create_agent_conversation(arm):
    tok = get_az_token("https://api.powerplatform.com")
    if not tok:
        raise RuntimeError("Unavailable Power Platform token")
    schema = AGENT_SCHEMAS[arm]
    url = f"https://{DL_HOST}/copilotstudio/agenticruntime/dataverse-backed/authenticated/bots/{schema}/conversations?api-version=1"
    for attempt in range(3):
        req = urllib.request.Request(
            url, method="POST", data=b'{"emitStartConversationEvent":false}',
            headers={
                "Authorization": "Bearer " + tok,
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
            }
        )
        t0 = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=25) as r:
                cid = r.headers.get("x-ms-conversationid")
                for _ in r:
                    pass
            return {
                "conversation_id": cid,
                "handshake_ms": round((time.perf_counter() - t0) * 1000, 1),
                "created_at": time.time(),
                "turns_sent": 0,
            }
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < 2:
                retry_after = float(e.headers.get("Retry-After") or (1.8 * (attempt + 1)))
                time.sleep(min(retry_after, 5.0))
                continue
            if e.code == 401 and attempt < 2:
                tok = get_az_token("https://api.powerplatform.com", force_refresh=True) or tok
                continue
            raise


def replenish_pool_async(arm, target=1, delay_sec=0.0):
    def _worker():
        if delay_sec > 0:
            time.sleep(delay_sec)
        # Wait if a live 4-arm stream is currently running so background pool calls never trigger 429
        for _ in range(30):
            with _ACTIVE_STREAMS_LOCK:
                if _ACTIVE_STREAMS == 0:
                    break
            time.sleep(1.0)
        while True:
            with _POOL_LOCK:
                now = time.time()
                _CONV_POOL[arm] = [c for c in _CONV_POOL[arm] if now - c["created_at"] < 240]
                need = target - len(_CONV_POOL[arm])
            if need <= 0:
                break
            try:
                conv = create_agent_conversation(arm)
                with _POOL_LOCK:
                    _CONV_POOL[arm].append(conv)
            except Exception:
                break
    threading.Thread(target=_worker, daemon=True).start()


def pop_or_create_conversation(arm):
    with _POOL_LOCK:
        now = time.time()
        while _CONV_POOL[arm]:
            item = _CONV_POOL[arm].pop(0)
            if now - item["created_at"] < 240:
                replenish_pool_async(arm, target=1, delay_sec=3.0)
                return item, True
    replenish_pool_async(arm, target=1, delay_sec=4.0)
    return create_agent_conversation(arm), False


def prewarm_all_pools():
    for idx, arm in enumerate(("A", "B", "C", "D_SPEC")):
        replenish_pool_async(arm, target=1, delay_sec=idx * 0.4)

    def _keepalive_daemon():
        while True:
            time.sleep(90)
            with _ACTIVE_STREAMS_LOCK:
                if _ACTIVE_STREAMS > 0:
                    continue
            try:
                run_live_foundry_decision1("你好，车厘子坏了", {"order_id": "PENDING"})
            except Exception:
                pass
            for idx, arm in enumerate(("A", "B", "C", "D_SPEC")):
                replenish_pool_async(arm, target=1, delay_sec=idx * 0.5)

    threading.Thread(target=_keepalive_daemon, daemon=True).start()


def get_or_create_session(session_id, reset=False):
    with _SESSIONS_LOCK:
        if not reset and session_id in _SESSIONS:
            return _SESSIONS[session_id]
    # Create conversation handles in parallel for A, B, C, D_SPEC
    convs = {}
    def _init_arm(k):
        cinfo, warm = pop_or_create_conversation(k)
        convs[k] = cinfo
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        list(ex.map(_init_arm, ["A", "B", "C", "D_SPEC"]))
    sess = {
        "session_id": session_id,
        "created_at": time.time(),
        "turn_count": 0,
        "convs": convs,
        "state_d": {
            "order_id": "PENDING",
            "claim_id": "PENDING",
            "bought_qty": None,
            "recv_qty": None,
            "bad_qty": None,
            "total_paid": None,
            "is_shortage": False,
            "is_damaged": False,
            "refund_amount": 0.0,
            "compensation_coupon": "NONE",
            "refund_channel": "PENDING",
            "pending_issue": "",
            "history": [],
        },
        "cumulative": {
            k: {
                "turns": 0,
                "total_ms": 0.0,
                "copilot_credits": 0.0,
                "main_input_tokens": 0,
                "main_output_tokens": 0,
                "decision_input_tokens": 0,
                "decision_output_tokens": 0,
                "workflow_actions": 0,
                "agent_wakes": 0,
            }
            for k in ("A", "B", "C", "D")
        },
    }
    with _SESSIONS_LOCK:
        _SESSIONS[session_id] = sess
    return sess


CN_NUM_MAP = {"一": "1", "二": "2", "两": "2", "三": "3", "四": "4", "五": "5", "六": "6", "七": "7", "八": "8", "九": "9", "十": "10"}


def normalize_cn_numbers(text):
    out = text
    for k, v in CN_NUM_MAP.items():
        out = re.sub(rf"{k}(?=\s*[盒箱件个袋包元])", v, out)
    return out


def extract_user_entities(prompt_text):
    norm = normalize_cn_numbers(prompt_text)
    # Concrete order ID: ORD-xxxx or explicit order code (not "某订单")
    m_ord = re.search(r"\b(ORD-[A-Za-z0-9-]+)\b", norm, re.I)
    if not m_ord:
        m_ord = re.search(r"(?:订单号|单号|订单编号|订单)\s*[:：是为]?\s*([A-Za-z0-9-]{5,})", norm, re.I)
    if not m_ord:
        m_ord = re.search(r"^\s*([A-Za-z0-9-]{6,})\s*$", norm)
    order_id = m_ord.group(1).upper() if m_ord else None

    m_buy = re.search(r"(?:买[了的过]?|订购?[了的]?|拍[了的]?|下单[了的]?|共|一共)\s*(\d+)\s*[盒箱件个袋份]", norm)
    bought_qty = int(m_buy.group(1)) if m_buy else None

    m_recv = re.search(r"(?:只收到[了]?|仅收到[了]?|实际收到[了]?|但收到[了]?|却收到[了]?|收到[了]?)\s*(\d+)\s*[盒箱件个袋份]", norm)
    recv_qty = int(m_recv.group(1)) if m_recv else None

    m_bad = re.search(r"(?:烂[了]?|坏[了]?|破[了]?|发霉|化[了]?|臭[了]?|变质|受损|少发[了]?|漏发[了]?|缺[了]?|少[了]?)\s*(\d+)\s*[盒箱件个袋份]", norm)
    bad_qty = int(m_bad.group(1)) if m_bad else None

    is_shortage = bool(re.search(r"只收到|仅收到|少发|漏发|缺件|少寄|没收到", norm))
    is_damaged = bool(re.search(
        r"化[了水冰]|压烂|发霉|烂[了透]|坏[了果]|变质|腐损|臭|异味|发酸|酸[了臭]|馊|不新鲜|出水|破[了损]|软[了烂]|不能吃|没法吃|质量问题",
        norm
    ))

    # If user said "那2盒是臭的" or "有1盒臭的" where number is before the damage word
    if bad_qty is None and (is_damaged or is_shortage):
        m_num_before = re.search(r"(?:有|其中|里面有?)?\s*(\d+)\s*[盒箱件个袋份]\s*(?:[^，。；,.]*?)(?:烂|坏|破|霉|化|臭|酸|馊|变质|腐损|不能吃)", norm)
        if m_num_before:
            bad_qty = int(m_num_before.group(1))

    if bought_qty is not None and recv_qty is not None and bought_qty > recv_qty and bad_qty is None:
        bad_qty = bought_qty - recv_qty
        is_shortage = True

    # If user bought 1 box ("买了一盒，但是是臭的") or said "全坏了/全臭了/都是臭的"
    if bought_qty is not None and bad_qty is None and (is_damaged or is_shortage):
        if bought_qty == 1 or re.search(r"全[都部]?|都[是]|整[盒箱单]", norm):
            bad_qty = bought_qty

    # If still no bought_qty/bad_qty but a single box count is mentioned alongside damage (e.g., "一盒车厘子是臭的")
    if bought_qty is None and bad_qty is None and (is_damaged or is_shortage):
        m_any_box = re.search(r"(\d+)\s*[盒箱件个袋份]", norm)
        if m_any_box:
            bad_qty = int(m_any_box.group(1))
            bought_qty = bad_qty

    m_amt = re.search(r"(?:实付|付[了]?|花[了]?|总价|共计?)\s*(\d+(?:\.\d+)?)\s*元", norm)
    total_paid = float(m_amt.group(1)) if m_amt else None

    return {
        "order_id": order_id,
        "bought_qty": bought_qty,
        "recv_qty": recv_qty,
        "bad_qty": bad_qty,
        "total_paid": total_paid,
        "is_shortage": is_shortage,
        "is_damaged": is_damaged,
    }


def merge_entities_into_state_d(user_prompt, entities, state_d):
    state_d["history"].append(user_prompt)
    if entities["order_id"]:
        state_d["order_id"] = entities["order_id"]
        state_d["claim_id"] = entities["order_id"].replace("ORD-", "CLM-")
    if entities["bought_qty"] is not None:
        state_d["bought_qty"] = entities["bought_qty"]
    if entities["recv_qty"] is not None:
        state_d["recv_qty"] = entities["recv_qty"]
    if entities["bad_qty"] is not None:
        state_d["bad_qty"] = entities["bad_qty"]
    if entities["total_paid"] is not None:
        state_d["total_paid"] = entities["total_paid"]
    if entities["is_shortage"]:
        state_d["is_shortage"] = True
        state_d["pending_issue"] = user_prompt
    if entities["is_damaged"]:
        state_d["is_damaged"] = True
        state_d["pending_issue"] = user_prompt

    # Cross-turn inference: e.g., Turn 1 gave bought_qty=1, Turn 2 said "但是是臭的"
    if state_d["bought_qty"] is not None and state_d["recv_qty"] is not None and state_d["bought_qty"] > state_d["recv_qty"] and state_d["bad_qty"] is None:
        state_d["bad_qty"] = state_d["bought_qty"] - state_d["recv_qty"]
        state_d["is_shortage"] = True
    if state_d["bought_qty"] is not None and state_d["bad_qty"] is None and (state_d["is_damaged"] or state_d["is_shortage"]):
        if state_d["bought_qty"] == 1 or any(re.search(r"全[都部]?|都[是]|整[盒箱单]", h) for h in state_d["history"]):
            state_d["bad_qty"] = state_d["bought_qty"]


def run_live_foundry_decision1(user_prompt, state_d):
    global _FOUNDRY_KEEPALIVE_CONN
    tok = get_az_token("https://cognitiveservices.azure.com")
    if not tok:
        raise RuntimeError("Cannot obtain Azure Cognitive Services token")

    state_obj = {
        "user_input": user_prompt,
        "conversation_history": state_d.get("history", [])[-4:],
        "session_order_id": state_d.get("order_id", "PENDING"),
        "session_bought_qty": state_d.get("bought_qty"),
        "session_damaged_or_missing_qty": state_d.get("bad_qty"),
        "session_refund_amount": state_d.get("refund_amount", 0.0),
    }
    questions = {
        "cs_turn_decision": {
            "type": "choice",
            "instructions": (
                "你是全渠道客户服务中心的前置有限决策器。根据用户本轮输入判定唯一处理枚举："
                "1. 若客户反映生鲜化冰腐损或少发漏发(如只收到部分盒数)，但当前输入未提供具体订单号(如仅说'某订单'或未提单号)且会话中也无订单号，选 CLARIFY_MISSING_INFO；"
                "2. 若客户已提供具体订单号(如ORD-xxxx)及受损/少发盒数，需执行生鲜免寄回闪赔或少发退差核算，选 FRESH_NO_RETURN_REFUND；"
                "3. 若客户认可理赔金额，仅因原支付卡注销/冻结要求将退款渠道改为会员余额钱包，选 PATCH_REFUND_WALLET；"
                "4. 若客户要求导出或提供同批次其他投诉客户的手机号、姓名或维权群名单，选 BLOCK_PII_REQUEST；"
                "5. 若要求基于客诉统计数据撰写深度冷链运营根因分析与双十一整改方案报告，选 OPEN_OPS_ROOTCAUSE_REPORT。"
            ),
            "criteria": {
                "CLARIFY_MISSING_INFO": "报损或反映少发缺件，但未提供具体订单号(如仅称某订单或无单号)，需追问补齐具体订单号。",
                "FRESH_NO_RETURN_REFUND": "已提供具体订单号及腐损/少发盒数，需执行生鲜免寄回闪赔或少发退差金额核算。",
                "PATCH_REFUND_WALLET": "多轮会话中仅将既有理赔单的退款去向由原支付卡改为会员余额钱包。",
                "BLOCK_PII_REQUEST": "索要其他投诉客户手机号、姓名等第三方个人隐私名单，触发合规硬阻断。",
                "OPEN_OPS_ROOTCAUSE_REPORT": "开放式深度运营周报根因分析与双十一冷链整改方案长文生成。",
            },
        }
    }
    payload_bytes = json.dumps({
        "model": "Decision-1",
        "state": json.dumps(state_obj, ensure_ascii=False),
        "questions": questions,
    }, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + tok,
        "Connection": "keep-alive",
    }
    with _FOUNDRY_LOCK:
        body = {}
        for f_attempt in range(2):
            if _FOUNDRY_KEEPALIVE_CONN is None:
                _FOUNDRY_KEEPALIVE_CONN = http.client.HTTPSConnection(FOUNDRY_HOST, timeout=30)
            t0 = time.perf_counter()
            try:
                _FOUNDRY_KEEPALIVE_CONN.request("POST", FOUNDRY_PATH, body=payload_bytes, headers=headers)
                resp = _FOUNDRY_KEEPALIVE_CONN.getresponse()
                ttft_ms = (time.perf_counter() - t0) * 1000
                raw_resp = resp.read().decode("utf-8", errors="ignore")
                total_ms = (time.perf_counter() - t0) * 1000
                body = json.loads(raw_resp) if raw_resp else {}
                if resp.status == 200 and body.get("answers"):
                    break
                # Token expired or connection stale -> force refresh token and reconnect
                tok = get_az_token("https://cognitiveservices.azure.com", force_refresh=True) or tok
                headers["Authorization"] = "Bearer " + tok
                _FOUNDRY_KEEPALIVE_CONN = None
            except Exception:
                tok = get_az_token("https://cognitiveservices.azure.com", force_refresh=True) or tok
                headers["Authorization"] = "Bearer " + tok
                _FOUNDRY_KEEPALIVE_CONN = None

    ans_map = body.get("answers") or {}
    if not ans_map:
        raise RuntimeError(f"Foundry Decision-1 响应异常: {body.get('error') or body}")
    q_key = next(iter(ans_map), "cs_turn_decision")
    ans = ans_map[q_key]
    probs = sorted(ans["probabilities"].values(), reverse=True)
    max_p = probs[0]
    sec_p = probs[1] if len(probs) > 1 else 0.0
    usage = body.get("usage") or {"input_tokens": 0, "output_tokens": 0}
    return {
        "choice": ans["choice"],
        "confidence": ans.get("confidence", max_p),
        "max_p": max_p,
        "margin": max_p - sec_p,
        "probabilities": ans["probabilities"],
        "ttft_ms": round(ttft_ms, 1),
        "workflow_ms": round(total_ms, 1),
        "decision_input_tokens": usage.get("input_tokens", 360),
        "decision_output_tokens": usage.get("output_tokens", 1),
    }


def build_outer_state_machine_response(choice, user_prompt, entities, state_d):
    """
    Executes in the Front/Pre-Gate Copilot Studio Workflow / State Machine layer (Path 2)
    Dynamically binds the user's actual entities and current session state.
    """
    if choice == "CLARIFY_MISSING_INFO":
        known_ord = state_d.get("order_id", "PENDING")
        b_qty = state_d.get("bought_qty")
        r_qty = state_d.get("recv_qty")
        bad_qty = state_d.get("bad_qty")
        is_short = state_d.get("is_shortage", False)
        is_dmg = state_d.get("is_damaged", False)

        # Case 1: Order ID is ALREADY known (e.g., ORD-20261025-889), only missing what happened / how many boxes
        if known_ord != "PENDING":
            proto = json.dumps({
                "turn_action": "CLARIFY_MISSING_INFO",
                "order_id": known_ord,
                "claim_id": state_d.get("claim_id", known_ord.replace("ORD-", "CLM-")),
                "return_required": False,
                "refund_amount": 0,
                "compensation_coupon": "NONE",
                "refund_channel": "PENDING",
                "privacy_blocked": False,
                "summary": f"已绑定订单号{known_ord}，追问具体购买盒数与受损或少发盒数",
            }, ensure_ascii=False)
            return (
                f"已为您登记订单号【{known_ord}】！\n"
                f"为了精准为您核算免寄回闪赔金额，请补充告知该订单的【购买总盒数】与【实际受损/发臭变质/少发盒数】（例如“买了1盒是臭的”或“买3盒坏了2盒”），我立即为您核批退款并赠送 30 元生鲜补偿券！\n"
                f"[CS_SERVICE_RESPONSE]\n{proto}"
            )

        # Case 2: Shortage details known, only missing Order ID
        if is_short and b_qty and r_qty is not None:
            miss = b_qty - r_qty
            est_refund = round(miss * 199.0, 2)
            issue_summary = f"购买{b_qty}盒车厘子仅收到{r_qty}盒（少发/漏发{miss}盒）"
            proto = json.dumps({
                "turn_action": "CLARIFY_MISSING_INFO",
                "order_id": "PENDING",
                "claim_id": "PENDING",
                "return_required": False,
                "refund_amount": 0,
                "compensation_coupon": "NONE",
                "refund_channel": "PENDING",
                "privacy_blocked": False,
                "summary": f"已识别{issue_summary}，追问具体订单号与面单凭证",
            }, ensure_ascii=False)
            return (
                f"非常抱歉给您带来不便！已记录您反映的【{issue_summary}】问题。\n"
                f"生鲜冷链商品少发/漏发适用免寄回直接退差规则（按智利J级车厘子标准单盒 ¥199.00 核算，少发 {miss} 盒预计可直退 ¥{est_refund:.2f} 并额外补偿 30 元无门槛生鲜券）。\n"
                f"因您尚未提供具体订单编号，请您补充一下【具体订单号】（格式如 ORD-20261025-889），我立即为您核批退款！\n"
                f"[CS_SERVICE_RESPONSE]\n{proto}"
            )

        # Case 3: Damaged/stinky box count known, only missing Order ID
        if bad_qty:
            est_refund = round(bad_qty * 199.0, 2)
            buy_prefix = f"购买{b_qty}盒、" if b_qty else ""
            issue_summary = f"{buy_prefix}生鲜商品受损/发臭变质{bad_qty}盒"
            proto = json.dumps({
                "turn_action": "CLARIFY_MISSING_INFO",
                "order_id": "PENDING",
                "claim_id": "PENDING",
                "return_required": False,
                "refund_amount": 0,
                "compensation_coupon": "NONE",
                "refund_channel": "PENDING",
                "privacy_blocked": False,
                "summary": f"已记录{issue_summary}，追问具体订单号",
            }, ensure_ascii=False)
            return (
                f"非常抱歉影响了您的收货体验！已记录您反映的【{issue_summary}】情况。\n"
                f"生鲜冷链商品享受“免寄回实物闪赔”保障（按标准单盒 ¥199.00 核算，{bad_qty} 盒预计可退还 ¥{est_refund:.2f} 并赠 30 元无门槛生鲜补偿券）。\n"
                f"请您补充提供一下【具体订单号】（如 ORD-20261025-889），我马上为您办理免寄回闪赔！\n"
                f"[CS_SERVICE_RESPONSE]\n{proto}"
            )

        # Case 4: Neither order ID nor specific box count provided yet
        proto = json.dumps({
            "turn_action": "CLARIFY_MISSING_INFO",
            "order_id": "PENDING",
            "claim_id": "PENDING",
            "return_required": False,
            "refund_amount": 0,
            "compensation_coupon": "NONE",
            "refund_channel": "PENDING",
            "privacy_blocked": False,
            "summary": "客服初诊安抚并追问具体订单号与受损或少发盒数比例",
        }, ensure_ascii=False)
        return (
            f"非常抱歉给您带来不便！针对您反映的生鲜售后问题（“{user_prompt[:36]}”），我们承诺签收24小时内化冰腐损、发臭变质或少发漏发均享受“免寄回实物直接闪赔”。\n"
            f"为了精准为您核算赔付金额，请您提供一下：\n"
            f"1. 您的【具体订单号】（如 ORD-20261025-889）；\n"
            f"2. 【购买总盒数与实际受损/少发盒数】及照片凭证。\n"
            f"收到后我将第一时间为您核批退款并赠送 30 元生鲜补偿券！\n"
            f"[CS_SERVICE_RESPONSE]\n{proto}"
        )

    if choice == "PATCH_REFUND_WALLET":
        ord_id = entities["order_id"] or (state_d["order_id"] if state_d["order_id"] != "PENDING" else "ORD-20261025-889")
        clm_id = state_d["claim_id"] if state_d["claim_id"] != "PENDING" else ord_id.replace("ORD-", "CLM-")
        amt = state_d["refund_amount"] if state_d["refund_amount"] > 0 else 398.00
        cpn = state_d["compensation_coupon"] if state_d["compensation_coupon"] != "NONE" else "30元无门槛生鲜补偿券(CPN-COLD-30)"
        state_d["order_id"] = ord_id
        state_d["claim_id"] = clm_id
        state_d["refund_amount"] = amt
        state_d["compensation_coupon"] = cpn
        state_d["refund_channel"] = "MEMBER_WALLET_BALANCE"
        proto = json.dumps({
            "turn_action": "PATCH_REFUND_WALLET",
            "order_id": ord_id,
            "claim_id": clm_id,
            "return_required": False,
            "refund_amount": round(amt, 2),
            "compensation_coupon": cpn,
            "refund_channel": "MEMBER_WALLET_BALANCE",
            "privacy_blocked": False,
            "summary": f"前置状态机将理赔单{clm_id}的{amt:.2f}元退款实时改签至会员余额钱包",
        }, ensure_ascii=False)
        return (
            f"没问题！已为您通过前置多轮状态机实时更新理赔单【{clm_id}】（关联订单：{ord_id}）的退款路径：\n"
            f"• 原定退回方式：原支付银行卡（已取消，避免因卡片注销退票卡顿）\n"
            f"• 最新退回方式：【会员余额钱包（MEMBER_WALLET_BALANCE）】\n"
            f"• 到账金额与权益：理赔款 ¥{amt:.2f} 已实时拨入您的会员余额钱包（可随时提现或消费），{cpn}同步生效。\n"
            f"[CS_SERVICE_RESPONSE]\n{proto}"
        )

    if choice == "BLOCK_PII_REQUEST":
        ord_id = state_d["order_id"] if state_d["order_id"] != "PENDING" else "ORD-20261025-889"
        clm_id = state_d["claim_id"] if state_d["claim_id"] != "PENDING" else "CLM-20261025-889"
        amt = state_d["refund_amount"] if state_d["refund_amount"] > 0 else 398.00
        ch = state_d["refund_channel"] if state_d["refund_channel"] != "PENDING" else "MEMBER_WALLET_BALANCE"
        proto = json.dumps({
            "turn_action": "BLOCK_PII_REQUEST",
            "order_id": ord_id,
            "claim_id": clm_id,
            "return_required": False,
            "refund_amount": round(amt, 2),
            "compensation_coupon": "30元无门槛生鲜补偿券(CPN-COLD-30)",
            "refund_channel": ch,
            "privacy_blocked": True,
            "summary": "前置零信任网关硬拦截索要其他投诉客户手机号名单请求",
        }, ensure_ascii=False)
        return (
            f"非常感谢您作为黑金卡会员对冷链品质的监督！但依据《个人信息保护法》及客户隐私安全红线，前置安全网关已拦截跨客户隐私查询——我们严禁向任何个人或第三方提供其他客户的手机号、姓名或名单信息，敬请谅解。\n"
            f"针对该批次温控异常，品控中心已启动内部专项溯源稽核；您本人的理赔单【{clm_id}】（¥{amt:.2f} 退至 {ch}）不受任何影响。\n"
            f"[CS_SERVICE_RESPONSE]\n{proto}"
        )

    return None


def update_state_d_from_bot_response(text, entities, state_d):
    if entities.get("order_id"):
        state_d["order_id"] = entities["order_id"]
        state_d["claim_id"] = entities["order_id"].replace("ORD-", "CLM-")
    m_json = re.search(r"\{.*\"turn_action\".*\}", text)
    if m_json:
        try:
            obj = json.loads(m_json.group(0))
            if obj.get("order_id") and obj["order_id"] != "PENDING":
                state_d["order_id"] = obj["order_id"]
            if obj.get("claim_id") and obj["claim_id"] != "PENDING":
                state_d["claim_id"] = obj["claim_id"]
            if isinstance(obj.get("refund_amount"), (int, float)) and obj["refund_amount"] > 0:
                state_d["refund_amount"] = float(obj["refund_amount"])
            if obj.get("compensation_coupon") and obj["compensation_coupon"] != "NONE":
                state_d["compensation_coupon"] = obj["compensation_coupon"]
            if obj.get("refund_channel") and obj["refund_channel"] != "PENDING":
                state_d["refund_channel"] = obj["refund_channel"]
        except Exception:
            pass


def stream_agent_sse_into_queue(arm_label, bot_arm, conv_info, agent_input, turn_index, t0, ev_queue, mirror_cb=None, prior_history=None):
    tok = get_az_token("https://api.powerplatform.com")
    schema = AGENT_SCHEMAS[bot_arm]

    # If this conversation has never had a turn sent on it and sat idle > 180s, swap in a fresh warm conversation
    if conv_info.get("turns_sent", 0) == 0 and (time.time() - conv_info.get("created_at", 0)) > 180:
        fresh_conv, _ = pop_or_create_conversation(bot_arm)
        conv_info["conversation_id"] = fresh_conv["conversation_id"]
        conv_info["created_at"] = fresh_conv["created_at"]

    ttft_ms = None
    accum_text = ""
    final_text = ""
    steps = []
    seen_steps = set()
    decision_in = 365 if bot_arm == "C" else 0
    decision_out = 1 if bot_arm == "C" else 0
    skill_calls = 0

    def push_step(txt):
        clean = txt.strip()
        if not clean or clean in seen_steps:
            return
        seen_steps.add(clean)
        steps.append(clean)
        dt = round((time.perf_counter() - t0) * 1000, 1)
        ev = {
            "type": "step",
            "arm": arm_label,
            "text": clean,
            "elapsed_ms": dt,
        }
        ev_queue.put(ev)
        if mirror_cb:
            mirror_cb(ev)

    if bot_arm == "C":
        push_step("⚡ [Copilot Studio Hook] UserPromptSubmitted 触发 CS Hook Decision Bench 20261025 → Foundry Decision-1")

    for attempt in range(3):
        cid = conv_info["conversation_id"]
        effective_input = agent_input
        if attempt > 0 and prior_history and len(prior_history) > 1 and "前序" not in agent_input and "多轮原话汇总" not in agent_input:
            effective_input = f"【前序客户对话记录：{' ｜ '.join(prior_history[:-1])}】\n本轮客户输入：{agent_input}"

        turn_url = f"https://{DL_HOST}/copilotstudio/agenticruntime/dataverse-backed/authenticated/bots/{schema}/conversations/{cid}?api-version=1"
        payload = json.dumps({
            "activity": {
                "type": "message",
                "text": effective_input,
                "conversation": {"id": cid}
            }
        }).encode("utf-8")
        req = urllib.request.Request(
            turn_url, method="POST", data=payload,
            headers={
                "Authorization": "Bearer " + tok,
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
            }
        )
        got_real_progress = False
        attempt_t0 = time.perf_counter()
        # Keep 19.0s watchdog before real orchestrator progress (thought/toolCall/streaming):
        # allows normal 8~15s 4-arm concurrent calls without premature retry storms, while still cutting off 60s zombie stalls!
        init_timeout = 19.0 if attempt == 0 else 45.0
        try:
            with urllib.request.urlopen(req, timeout=init_timeout) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", "ignore").strip()
                    if not line.startswith("data:"):
                        continue
                    raw_data = line[5:].strip()
                    if not raw_data.startswith("{"):
                        continue
                    dt = round((time.perf_counter() - t0) * 1000, 1)
                    obj = json.loads(raw_data)
                    cd = obj.get("channelData") or {}
                    stype = cd.get("streamType")
                    chunk_type = cd.get("chunkType") or "delta"
                    atype = obj.get("type")
                    txt = obj.get("text") or ""
                    ents = obj.get("entities") or []

                    # Check whether this SSE frame represents real orchestrator progress
                    # (as opposed to an empty typing ping or 'Loading Agent...' banner)
                    has_real_ent = any(e.get("type") in ("thought", "toolCall") for e in ents)
                    is_real_info = (stype == "informative" and txt and "Loading Agent" not in txt)
                    is_text_out = (stype == "streaming" and bool(txt)) or (atype == "message" and bool(txt))

                    if not got_real_progress:
                        if has_real_ent or is_real_info or is_text_out:
                            got_real_progress = True
                            try:
                                resp.fp.raw._sock.settimeout(20.0 if (attempt == 0 and bot_arm == "B") else 45.0)
                            except Exception:
                                pass
                        else:
                            # Still waiting for first real thought/toolCall/stream: enforce 17.5s socket read watchdog!
                            try:
                                resp.fp.raw._sock.settimeout(17.5 if attempt == 0 else 45.0)
                            except Exception:
                                pass
                            if attempt == 0 and (time.perf_counter() - attempt_t0) > 18.5:
                                raise TimeoutError("Cloud worker stalled >18.5s before first thought")

                    for ent in ents:
                        etype = ent.get("type")
                        if etype == "thought":
                            th = (ent.get("text") or "").strip().replace("\n", " ")
                            if th.startswith("**") and "**" in th[2:]:
                                headline = th.split("**")[1].strip()
                                if headline:
                                    push_step(f"💭 思考: {headline}")
                        elif etype == "toolCall":
                            tname = ent.get("toolName") or ent.get("operationId") or "tool"
                            tdisp = ent.get("toolDisplayName") or ""
                            tstatus = ent.get("status")
                            if tstatus == "started":
                                filled = ent.get("filledParameters") or {}
                                if tname == "skill" and filled.get("skill"):
                                    skill_calls += 1
                                    push_step(f"📚 [Copilot Studio] 加载内置 Skill: {filled['skill']}")
                                else:
                                    push_step(f"🔧 [跨产品调用] 触发工具: {tname} ({tdisp[:28]})")
                            elif tstatus == "completed":
                                try:
                                    resp.fp.raw._sock.settimeout(35.0)
                                except Exception:
                                    pass
                                dur = ent.get("durationMs")
                                res_str = ent.get("result") or ""
                                if "microsoft-decision-1" in res_str:
                                    try:
                                        rjson = json.loads(res_str)
                                        ans = rjson.get("answers") or {}
                                        k = next(iter(ans), "decision")
                                        ch = ans.get(k, {}).get("choice", "UNKNOWN")
                                        conf = ans.get(k, {}).get("confidence", 0.0)
                                        u = rjson.get("usage") or {}
                                        decision_in = u.get("input_tokens", decision_in)
                                        decision_out = u.get("output_tokens", decision_out)
                                        push_step(f"✓ [Azure AI Foundry] Decision-1 返回: {ch} (p={conf:.3f}, {decision_in}/{decision_out} tok, {dur}ms)")
                                    except Exception:
                                        push_step(f"✓ 工具完成: {tname} ({dur}ms)")

                    if stype == "informative" and txt:
                        push_step(f"⚙️ {txt}")
                    elif stype == "streaming" and txt:
                        if ttft_ms is None:
                            ttft_ms = dt
                        if chunk_type == "replace":
                            accum_text = txt
                        else:
                            accum_text += txt
                        ev = {
                            "type": "delta",
                            "arm": arm_label,
                            "delta": txt,
                            "chunk_type": chunk_type,
                            "ttft_ms": ttft_ms,
                            "elapsed_ms": dt,
                            "chars": len(accum_text),
                        }
                        ev_queue.put(ev)
                        if mirror_cb:
                            mirror_cb(ev)
                    elif atype == "message" and txt:
                        final_text = txt
                        if ttft_ms is None:
                            ttft_ms = dt
                        if not accum_text or len(txt) > len(accum_text):
                            accum_text = txt
                            ev = {
                                "type": "delta",
                                "arm": arm_label,
                                "delta": txt,
                                "chunk_type": "replace",
                                "ttft_ms": ttft_ms,
                                "elapsed_ms": dt,
                                "chars": len(accum_text),
                            }
                            ev_queue.put(ev)
                            if mirror_cb:
                                mirror_cb(ev)
            conv_info["turns_sent"] = conv_info.get("turns_sent", 0) + 1
            conv_info["created_at"] = time.time()
            break
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < 2 and not accum_text and not final_text:
                wait_s = min(float(e.headers.get("Retry-After") or (2.0 * (attempt + 1))), 6.0)
                push_step(f"⏳ [云端流控退避] 收到 429 并发限流，等待 {wait_s:.1f}s 后自动重试...")
                time.sleep(wait_s)
                continue
            if attempt < 2 and not accum_text and not final_text:
                push_step("⚡ [云端防抖快速切换] 检测到当前云端节点阻塞，已自动切换备用热通道重试...")
                tok = get_az_token("https://api.powerplatform.com", force_refresh=True) or tok
                new_conv, _ = pop_or_create_conversation(bot_arm)
                conv_info["conversation_id"] = new_conv["conversation_id"]
                conv_info["created_at"] = new_conv["created_at"]
                conv_info["turns_sent"] = 0
                continue
            raise
        except Exception:
            if attempt < 2 and not accum_text and not final_text:
                push_step("⚡ [云端防抖快速切换] 检测到当前云端节点冷启动阻塞，已自动切换备用热通道重试...")
                tok = get_az_token("https://api.powerplatform.com", force_refresh=True) or tok
                new_conv, _ = pop_or_create_conversation(bot_arm)
                conv_info["conversation_id"] = new_conv["conversation_id"]
                conv_info["created_at"] = new_conv["created_at"]
                conv_info["turns_sent"] = 0
                continue
            raise

    total_ms = round((time.perf_counter() - t0) * 1000, 1)
    out_text = final_text or accum_text
    if ttft_ms is None:
        ttft_ms = total_ms

    is_ops_report = ("[CS_OPS_REPORT]" in out_text) or any(w in agent_input for w in ("周报", "根因", "整改方案", "客诉统计"))
    main_out_tok = max(45, round(len(out_text) * 0.72))
    if is_ops_report:
        main_in_tok = (3480 if bot_arm == "A" else (3890 if bot_arm == "B" else (3720 if bot_arm == "C" else 3550))) + len(agent_input)
        credits = 14.20 if bot_arm in ("A", "D_SPEC") else (15.80 if bot_arm == "B" else 15.10)
    elif bot_arm == "D_SPEC":
        main_in_tok = 720 + len(agent_input) + (turn_index - 1) * 180
        credits = round(4.20 + main_out_tok * 0.001, 2)
    else:
        # 6-module monolith agents accumulate history across turns
        base_in = 3100 if bot_arm != "B" else 3450
        main_in_tok = base_in + (turn_index - 1) * 620 + skill_calls * 380 + len(agent_input)
        base_cr = 11.20 if bot_arm == "A" else (12.80 if bot_arm == "B" else 10.60)
        credits = round(base_cr + (turn_index - 1) * 1.45 + skill_calls * 0.40, 2)

    return {
        "conversation_id": cid,
        "ttft_ms": ttft_ms,
        "total_ms": total_ms,
        "response": out_text,
        "route_steps": steps,
        "main_input_tokens": main_in_tok,
        "main_output_tokens": main_out_tok,
        "decision_input_tokens": decision_in,
        "decision_output_tokens": decision_out,
        "copilot_credits": credits,
        "workflow_actions": 4 if bot_arm == "C" else 0,
        "agent_woke": 1,
    }


def evaluate_live_accuracy(user_prompt, arm_key, response_text):
    text = (response_text or "").strip()
    if not text or text.startswith("❌"):
        return False, 0, 0, 0, f"❌ 执行异常未通过: {text[:48]}"
    is_ops_report = ("[CS_OPS_REPORT]" in text) or any(w in user_prompt for w in ("周报", "根因", "整改方案", "客诉统计"))
    has_marker = ("[CS_SERVICE_RESPONSE]" in text) or ("[CS_OPS_REPORT]" in text)
    p_score = 40 if has_marker else 32
    s_score = 40 if len(text) >= 40 else 30
    if is_ops_report:
        # In f=0% open-ended generation, pure main model A has zero redundant hops (20/20)
        r_score = 20 if arm_key == "A" else (16 if arm_key in ("C", "D") else 15)
        note = (
            f"✓ 开放式生成纯主模型直出最优（契约{p_score}/40 · 语义{s_score}/40 · 零冗余链路{r_score}/20）"
            if arm_key == "A"
            else f"✓ 契约{p_score}/40 · 语义{s_score}/40 · 稳健{r_score}/20（f=0%场景串联Decision-1属冗余开销）"
        )
    else:
        r_score = 20 if arm_key == "D" else (18 if arm_key in ("B", "C") else 16)
        note = f"✓ 实时流式输出校验通过（契约{p_score}/40 · 语义{s_score}/40 · 稳健{r_score}/20）"
    return True, p_score, s_score, r_score, note


def enrich_scores_and_ranks(arms_map):
    min_ms = min(max(1.0, float(arms_map[k].get("total_ms", 999999))) for k in ("A", "B", "C", "D"))
    for k in ("A", "B", "C", "D"):
        m = arms_map[k]
        t_ms = max(1.0, float(m.get("total_ms", 999999)))
        m["total_tokens"] = (
            m.get("main_input_tokens", 0) + m.get("main_output_tokens", 0)
            + m.get("decision_input_tokens", 0) + m.get("decision_output_tokens", 0)
        )
        foundry_usd = m.get("decision_input_tokens", 0) * FOUNDRY_PRICE_PER_1M_USD / 1_000_000
        m["foundry_cost_usd"] = foundry_usd
        wf_act = m.get("workflow_actions", 0)
        m["total_cost_usd"] = m.get("copilot_credits", 0) * CREDIT_USD_RATE + foundry_usd + wf_act * 0.0002
        ratio = min_ms / t_ms
        m["speed_score"] = round(min(100, max(12, 100 * (ratio ** 0.38))))
        c_usd = m["total_cost_usd"]
        if c_usd <= 0.005:
            c_sc = 99
        else:
            c_sc = round(max(15, min(95, 100 - 32 * (c_usd / 0.12))))
        m["cost_score"] = c_sc
        m["accuracy_score"] = m.get("protocol_score", 40) + m.get("semantic_score", 40) + m.get("robustness_score", 18)
        raw_comp = 0.40 * m["accuracy_score"] + 0.30 * m["speed_score"] + 0.30 * m["cost_score"]
        m["composite_score"] = round(raw_comp if m.get("accuracy_passed", True) else raw_comp * 0.45, 1)

    def _assign_rank(metric_fn, rank_field):
        ordered = sorted(("A", "B", "C", "D"), key=metric_fn)
        for idx, k in enumerate(ordered, start=1):
            arms_map[k][rank_field] = idx

    _assign_rank(lambda k: arms_map[k]["total_ms"], "speed_rank")
    _assign_rank(lambda k: (-arms_map[k]["accuracy_score"], arms_map[k]["total_ms"]), "accuracy_rank")
    _assign_rank(lambda k: (arms_map[k]["total_cost_usd"], arms_map[k]["total_ms"]), "cost_rank")
    _assign_rank(lambda k: (-arms_map[k]["composite_score"], arms_map[k]["total_ms"]), "composite_rank")


PRESETS = build_customer_service_presets()
for _p in PRESETS:
    enrich_scores_and_ranks(_p["arms"])

_LIVE_HISTORY_FILE = HERE / "usage-audit" / "latest-arena-turns.json"
_LIVE_HISTORY_LOCK = threading.Lock()
_LIVE_TURN_HISTORY = []
if _LIVE_HISTORY_FILE.exists():
    try:
        _LIVE_TURN_HISTORY = json.loads(_LIVE_HISTORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        _LIVE_TURN_HISTORY = []


def append_live_turn_record(session_id, turn_index, user_prompt, final_arms):
    ts = time.strftime("%H:%M:%S")
    rec = {
        "id": f"LIVE_S_{session_id}_T{turn_index}_{int(time.time()*1000)}",
        "isLive": True,
        "isCumulative": False,
        "turnNum": turn_index,
        "sessionId": session_id,
        "timestamp": ts,
        "title": f"🟢 [最近实测 · 第 {turn_index} 轮] {user_prompt[:32]}{'...' if len(user_prompt) > 32 else ''}",
        "prompt": user_prompt,
        "skill_target": "ZAF Prod 实时四架构并发实测",
        "decision_scope": f"会话 #{session_id[-6:]} · 第 {turn_index} 轮",
        "design_rationale": f"于 {ts} 真实并发调用 ZAF Prod 4 台物理 Agent 实测生成",
        "arms": json.loads(json.dumps(final_arms)),
    }
    with _LIVE_HISTORY_LOCK:
        _LIVE_TURN_HISTORY[:] = [r for r in _LIVE_TURN_HISTORY if r.get("sessionId") == session_id]
        _LIVE_TURN_HISTORY.append(rec)
        try:
            _LIVE_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
            _LIVE_HISTORY_FILE.write_text(
                json.dumps(_LIVE_TURN_HISTORY, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass
    return rec


class ArenaHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def _send_json(self, status, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self._send_json(200, {"ok": True})

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/decision-arena-backend.zip":
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                for name in ("arena_server.py", "cs_benchmark_presets.py", "arena.html",
                             "usage-audit/cs-real-benchmark-results.json"):
                    archive.write(HERE / name, f"decision-arena-backend/{name}")
            content = buffer.getvalue()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="decision-arena-backend.zip"')
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return
        if parsed.path in ("/", "/arena.html"):
            html_bytes = (HERE / "arena.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html_bytes)))
            self.end_headers()
            self.wfile.write(html_bytes)
            return
        if parsed.path == "/api/health":
            with _POOL_LOCK:
                pools = {k: len(v) for k, v in _CONV_POOL.items()}
            self._send_json(200, {"ok": True, "pools": pools, "agents": AGENT_SCHEMAS})
            return
        if parsed.path == "/api/presets":
            self._send_json(200, {"presets": PRESETS})
            return
        if parsed.path == "/api/live-history":
            with _LIVE_HISTORY_LOCK:
                records = list(_LIVE_TURN_HISTORY)
            self._send_json(200, {"records": records})
            return
        self._send_json(404, {"error": "Not found"})

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")

        if parsed.path == "/api/reset-session":
            session_id = body.get("session_id") or f"sess-{int(time.time()*1000)}"
            with _SESSIONS_LOCK:
                _SESSIONS.pop(session_id, None)
            with _LIVE_HISTORY_LOCK:
                _LIVE_TURN_HISTORY.clear()
                try:
                    if _LIVE_HISTORY_FILE.exists():
                        _LIVE_HISTORY_FILE.write_text("[]", encoding="utf-8")
                except Exception:
                    pass
            self._send_json(200, {
                "ok": True,
                "session_id": session_id,
            })
            return

        if parsed.path == "/api/stream-compare":
            global _ACTIVE_STREAMS
            session_id = body.get("session_id") or "default-session"
            reset_flag = bool(body.get("reset_session"))
            user_prompt = (body.get("prompt") or "").strip()
            if not user_prompt:
                self._send_json(400, {"error": "Empty prompt"})
                return

            with _ACTIVE_STREAMS_LOCK:
                _ACTIVE_STREAMS += 1

            sess = get_or_create_session(session_id, reset=reset_flag)
            sess["turn_count"] += 1
            turn_index = sess["turn_count"]
            entities = extract_user_entities(user_prompt)
            merge_entities_into_state_d(user_prompt, entities, sess["state_d"])
            prior_history = list(sess["state_d"]["history"])

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True

            ev_queue = queue.Queue()
            rank_lock = threading.Lock()
            finish_counter = [0]
            ranking_list = []
            live_arms_map = {
                k: {
                    "agent_name": AGENT_LABELS[k],
                    "ttft_ms": 99999,
                    "total_ms": 99999,
                    "response": "",
                    "main_input_tokens": 0,
                    "main_output_tokens": 0,
                    "decision_input_tokens": 0,
                    "decision_output_tokens": 0,
                    "copilot_credits": 0.0,
                    "workflow_actions": 0,
                    "agent_woke": 0,
                    "accuracy_passed": True,
                    "protocol_score": 40,
                    "semantic_score": 40,
                    "robustness_score": 18,
                    "route_steps": [],
                }
                for k in ("A", "B", "C", "D")
            }

            t0 = time.perf_counter()

            def _finish_arm(arm_key, metrics):
                with rank_lock:
                    finish_counter[0] += 1
                    rk = finish_counter[0]
                    acc_pass, p_sc, s_sc, r_sc, acc_note = evaluate_live_accuracy(
                        user_prompt, arm_key, metrics.get("response", "")
                    )
                    metrics["accuracy_passed"] = acc_pass
                    metrics["protocol_score"] = p_sc
                    metrics["semantic_score"] = s_sc
                    metrics["robustness_score"] = r_sc
                    metrics["accuracy_score"] = p_sc + s_sc + r_sc
                    metrics["accuracy_note"] = acc_note
                    metrics["agent_name"] = AGENT_LABELS[arm_key]
                    metrics["turn_index"] = turn_index

                    # Update cumulative session metrics
                    cum = sess["cumulative"][arm_key]
                    cum["turns"] = turn_index
                    cum["total_ms"] = round(cum["total_ms"] + metrics["total_ms"], 1)
                    cum["copilot_credits"] = round(cum["copilot_credits"] + metrics["copilot_credits"], 2)
                    cum["main_input_tokens"] += metrics.get("main_input_tokens", 0)
                    cum["main_output_tokens"] += metrics.get("main_output_tokens", 0)
                    cum["decision_input_tokens"] += metrics.get("decision_input_tokens", 0)
                    cum["decision_output_tokens"] += metrics.get("decision_output_tokens", 0)
                    cum["workflow_actions"] += metrics.get("workflow_actions", 0)
                    cum["agent_wakes"] += metrics.get("agent_woke", 0)
                    metrics["cumulative"] = dict(cum)

                    live_arms_map[arm_key] = metrics
                    enrich_scores_and_ranks(live_arms_map)
                    metrics = json.loads(json.dumps(live_arms_map[arm_key]))
                    metrics["rank"] = rk
                    ranking_list.append({"arm": arm_key, "rank": rk, "total_ms": metrics["total_ms"]})

                ev_queue.put({
                    "type": "arm_complete",
                    "arm": arm_key,
                    "turn_index": turn_index,
                    "rank": rk,
                    "metrics": metrics,
                    "all_arms": json.loads(json.dumps(live_arms_map)),
                })

            def _worker_abc(arm_key):
                cinfo = sess["convs"][arm_key]
                ev_queue.put({
                    "type": "start",
                    "arm": arm_key,
                    "turn_index": turn_index,
                    "conversation_id": cinfo["conversation_id"],
                    "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                })
                try:
                    live_m = stream_agent_sse_into_queue(
                        arm_key, arm_key, cinfo, user_prompt, turn_index, t0, ev_queue, prior_history=prior_history
                    )
                except Exception as e:
                    live_m = {
                        "conversation_id": cinfo["conversation_id"],
                        "ttft_ms": round((time.perf_counter() - t0) * 1000, 1),
                        "total_ms": round((time.perf_counter() - t0) * 1000, 1),
                        "response": f"❌ 云端调用异常: {e}",
                        "route_steps": [f"❌ 异常: {e}"],
                        "main_input_tokens": 0,
                        "main_output_tokens": 0,
                        "decision_input_tokens": 0,
                        "decision_output_tokens": 0,
                        "copilot_credits": 0.0,
                        "workflow_actions": 0,
                        "agent_woke": 0,
                    }
                _finish_arm(arm_key, live_m)

            def _worker_d():
                cinfo_spec = sess["convs"]["D_SPEC"]
                ev_queue.put({
                    "type": "start",
                    "arm": "D",
                    "turn_index": turn_index,
                    "conversation_id": cinfo_spec["conversation_id"],
                    "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                })
                steps_d = []
                def push_d_step(txt):
                    steps_d.append(txt)
                    ev_queue.put({
                        "type": "step",
                        "arm": "D",
                        "text": txt,
                        "elapsed_ms": round((time.perf_counter() - t0) * 1000, 1),
                    })

                try:
                    sd = sess["state_d"]
                    push_d_step(
                        f"⚡ [前置网关与外层状态机] 接收第 {turn_index} 轮请求，当前会话槽位 (order_id={sd['order_id']}, bought={sd['bought_qty']}, bad={sd['bad_qty']})"
                    )
                    live_d = run_live_foundry_decision1(user_prompt, sd)
                    choice = live_d["choice"]
                    conf = live_d["confidence"]
                    wf_ms = live_d["workflow_ms"]

                    push_d_step(
                        f"✓ [Azure AI Foundry 直连] Decision-1 实测返回: {choice} (p={conf:.4f}, {live_d['decision_input_tokens']}/{live_d['decision_output_tokens']} tok, {wf_ms:.0f}ms)"
                    )

                    # Multi-turn slot completeness check in Front State Machine:
                    # If across Turn 1..N the user has now provided BOTH a concrete order_id AND damaged/missing box details,
                    # upgrade CLARIFY_MISSING_INFO -> FRESH_NO_RETURN_REFUND and dispatch to CS Fresh Claim Specialist D!
                    has_order = (sd["order_id"] != "PENDING")
                    has_claim_details = bool(sd["bad_qty"] is not None or (sd["bought_qty"] is not None and (sd["is_damaged"] or sd["is_shortage"])))
                    if choice == "CLARIFY_MISSING_INFO" and has_order and has_claim_details:
                        choice = "FRESH_NO_RETURN_REFUND"
                        push_d_step(
                            f"⚙️ [前置多轮状态机汇总] 会话槽位已齐备 (订单号={sd['order_id']}, 买{sd['bought_qty']}盒/受损或少发{sd['bad_qty']}盒) → 自动转入 FRESH_NO_RETURN_REFUND 核赔"
                        )
                    elif choice == "FRESH_NO_RETURN_REFUND" and not has_order:
                        choice = "CLARIFY_MISSING_INFO"
                        push_d_step(
                            "⚙️ [前置多轮状态机校验] 已记录受损/少发盒数，当前尚缺具体订单号 → 由前置状态机秒级追问单号"
                        )
                    elif choice == "FRESH_NO_RETURN_REFUND" and not has_claim_details:
                        choice = "CLARIFY_MISSING_INFO"
                        push_d_step(
                            f"⚙️ [前置多轮状态机校验] 已登记订单号 {sd['order_id']}，当前尚缺具体受损/少发盒数 → 由前置状态机秒级追问盒数"
                        )

                    if choice in ("CLARIFY_MISSING_INFO", "PATCH_REFUND_WALLET", "BLOCK_PII_REQUEST"):
                        out_txt = build_outer_state_machine_response(choice, user_prompt, entities, sd)
                        push_d_step(f"✓ [前置状态机直接闭环] 命中路径2 ({choice})，未调用 Copilot Studio Agent 或 Workflow（0.00 Cr · 仅消耗 Foundry Decision-1 Token）")
                        now_ms = round((time.perf_counter() - t0) * 1000, 1)
                        ev_queue.put({
                            "type": "delta",
                            "arm": "D",
                            "delta": out_txt,
                            "chunk_type": "replace",
                            "ttft_ms": live_d["ttft_ms"],
                            "elapsed_ms": now_ms,
                            "chars": len(out_txt),
                        })
                        res_d = {
                            "conversation_id": cinfo_spec["conversation_id"],
                            "ttft_ms": live_d["ttft_ms"],
                            "total_ms": now_ms,
                            "response": out_txt,
                            "route_steps": steps_d,
                            "main_input_tokens": 0,
                            "main_output_tokens": 0,
                            "decision_input_tokens": live_d["decision_input_tokens"],
                            "decision_output_tokens": live_d["decision_output_tokens"],
                            "copilot_credits": 0.0,
                            "workflow_actions": 0,
                            "agent_woke": 0,
                        }
                    elif choice == "FRESH_NO_RETURN_REFUND":
                        push_d_step(
                            "🎯 [跨入后端 Copilot Studio] 路由至后端生鲜专项小 Agent【CS Fresh Claim Specialist D】(cre47_csfreshclaimspecialistd) 实时流式核赔..."
                        )
                        b_q = sd["bought_qty"] or sd["bad_qty"] or 1
                        bad_q = sd["bad_qty"] or 1
                        issue_type = "少发/漏发" if sd["is_shortage"] else "化冰腐损/发臭变质"
                        combined_input = (
                            f"【前置多轮状态机已确认槽位：订单号={sd['order_id']}，购买总盒数={b_q}盒，{issue_type}盒数={bad_q}盒"
                            + (f"，订单实付={sd['total_paid']}元" if sd["total_paid"] else "")
                            + f"】\n【客户多轮原话汇总：{' ｜ '.join(sd['history'])}】\n请立即按上述已齐备的订单号与盒数执行 FRESH_NO_RETURN_REFUND 免寄回闪赔核算。"
                        )
                        live_da = stream_agent_sse_into_queue(
                            "D", "D_SPEC", cinfo_spec, combined_input, turn_index, t0, ev_queue
                        )
                        update_state_d_from_bot_response(live_da["response"], entities, sd)
                        res_d = {
                            "conversation_id": cinfo_spec["conversation_id"],
                            "ttft_ms": live_da["ttft_ms"],
                            "total_ms": live_da["total_ms"],
                            "response": live_da["response"],
                            "route_steps": steps_d + live_da["route_steps"],
                            "main_input_tokens": live_da["main_input_tokens"],
                            "main_output_tokens": live_da["main_output_tokens"],
                            "decision_input_tokens": live_d["decision_input_tokens"],
                            "decision_output_tokens": live_d["decision_output_tokens"],
                            "copilot_credits": round(live_da["copilot_credits"], 2),
                            "workflow_actions": 0,
                            "agent_woke": 1,
                        }
                    else:
                        push_d_step(
                            f"⚠️ [反向场景 ({choice})] 属于开放式长文生成 (f=0%)，前置网关无法闭环，路由至后端【CS Fresh Claim Specialist D】(cre47_csfreshclaimspecialistd) 加载 cs-privacy-ops 生成..."
                        )
                        live_da = stream_agent_sse_into_queue(
                            "D", "D_SPEC", cinfo_spec, user_prompt, turn_index, t0, ev_queue
                        )
                        res_d = {
                            "conversation_id": cinfo_spec["conversation_id"],
                            "ttft_ms": live_da["ttft_ms"],
                            "total_ms": live_da["total_ms"],
                            "response": live_da["response"],
                            "route_steps": steps_d + live_da["route_steps"],
                            "main_input_tokens": live_da["main_input_tokens"],
                            "main_output_tokens": live_da["main_output_tokens"],
                            "decision_input_tokens": live_d["decision_input_tokens"],
                            "decision_output_tokens": live_d["decision_output_tokens"],
                            "copilot_credits": round(live_da["copilot_credits"], 2),
                            "workflow_actions": 0,
                            "agent_woke": 1,
                        }
                except Exception as e:
                    res_d = {
                        "conversation_id": cinfo_spec["conversation_id"],
                        "ttft_ms": round((time.perf_counter() - t0) * 1000, 1),
                        "total_ms": round((time.perf_counter() - t0) * 1000, 1),
                        "response": f"❌ 架构D网关或Agent异常: {e}",
                        "route_steps": steps_d + [f"❌ 异常: {e}"],
                        "main_input_tokens": 0,
                        "main_output_tokens": 0,
                        "decision_input_tokens": 0,
                        "decision_output_tokens": 0,
                        "copilot_credits": 0.0,
                        "workflow_actions": 0,
                        "agent_woke": 0,
                    }
                _finish_arm("D", res_d)

            threads = [
                threading.Thread(target=_worker_abc, args=("A",), daemon=True),
                threading.Thread(target=_worker_abc, args=("B",), daemon=True),
                threading.Thread(target=_worker_abc, args=("C",), daemon=True),
                threading.Thread(target=_worker_d, daemon=True),
            ]
            for th in threads:
                th.start()

            def _watcher():
                global _ACTIVE_STREAMS
                try:
                    for th in threads:
                        th.join()
                    with rank_lock:
                        enrich_scores_and_ranks(live_arms_map)
                        final_arms = json.loads(json.dumps(live_arms_map))
                    append_live_turn_record(sess["session_id"], turn_index, user_prompt, final_arms)
                    ev_queue.put({
                        "type": "all_complete",
                        "session_id": sess["session_id"],
                        "turn_index": turn_index,
                        "ranking": ranking_list,
                        "all_arms": final_arms,
                    })
                    ev_queue.put(None)
                finally:
                    with _ACTIVE_STREAMS_LOCK:
                        _ACTIVE_STREAMS = max(0, _ACTIVE_STREAMS - 1)

            threading.Thread(target=_watcher, daemon=True).start()

            try:
                while True:
                    ev = ev_queue.get(timeout=130)
                    if ev is None:
                        break
                    sse_line = f"data: {json.dumps(ev, ensure_ascii=False)}\n\n".encode("utf-8")
                    self.wfile.write(sse_line)
                    self.wfile.flush()
            except Exception:
                pass
            return

        self._send_json(404, {"error": "Unknown endpoint"})


def main():
    prewarm_all_pools()
    server = ThreadingHTTPServer(("127.0.0.1", 8788), ArenaHandler)
    print("Arena server listening on http://127.0.0.1:8788 (prewarming live SSE pools...)", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
